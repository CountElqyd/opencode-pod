---
description: Resume work from previous session with full context restoration
tools:
  read: true
  bash: true
  write: true
  question: true
  skill: true
---

<objective>
Restore complete project context and resume work seamlessly from previous session.

Routes to the resume-project workflow which handles:

- STATE.md loading (or reconstruction if missing)
- Checkpoint detection (.continue-here files)
- Incomplete work detection (PLAN without SUMMARY)
- Status presentation
- Context-aware next action routing
  </objective>

<execution_context>
@/home/floyddan/.config/opencode/gsd-core/workflows/resume-project.md
</execution_context>

<process>
Execute end-to-end.
</process>
