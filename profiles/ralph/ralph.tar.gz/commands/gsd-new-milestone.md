---
description: Start a new milestone cycle — update PROJECT.md and route to requirements
argument-hint: "[milestone name, e.g., 'v1.1 Notifications']"
requires: [new-project, phase, plan-phase]
tools:
  read: true
  write: true
  bash: true
  agent: true
  question: true
---
<objective>
Start a new milestone: questioning → research (optional) → requirements → roadmap.

Brownfield equivalent of new-project. Project exists, PROJECT.md has history. Gathers "what's next", updates PROJECT.md, then runs requirements → roadmap cycle.

**Creates/Updates:**
- `.planning/PROJECT.md` — updated with new milestone goals
- `.planning/research/` — domain research (optional, NEW features only)
- `.planning/REQUIREMENTS.md` — scoped requirements for this milestone
- `.planning/ROADMAP.md` — phase structure (continues numbering)
- `.planning/STATE.md` — reset for new milestone

**After:** `/gsd-plan-phase [N]` to start execution.
</objective>

<execution_context>
@/home/floyddan/.config/opencode/gsd-core/workflows/new-milestone.md
@/home/floyddan/.config/opencode/gsd-core/references/questioning.md
@/home/floyddan/.config/opencode/gsd-core/references/ui-brand.md
@/home/floyddan/.config/opencode/gsd-core/templates/project.md
@/home/floyddan/.config/opencode/gsd-core/templates/requirements.md
</execution_context>

<context>
Milestone name: $ARGUMENTS (optional - will prompt if not provided)

Project and milestone context files are resolved inside the workflow (`init new-milestone`) and delegated via `<files_to_read>` blocks where subagents are used.
</context>

<process>
Execute end-to-end.
Preserve all workflow gates (validation, questioning, research, requirements, roadmap approval, commits).
</process>
